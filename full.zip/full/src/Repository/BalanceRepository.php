<?php

namespace App\Repository;

use App\Entity\Balance;
use App\Entity\User;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\NonUniqueResultException;
use Doctrine\ORM\NoResultException;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method Balance|null find($id, $lockMode = null, $lockVersion = null)
 * @method Balance|null findOneBy(array $criteria, array $orderBy = null)
 * @method Balance[]    findAll()
 * @method Balance[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class BalanceRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Balance::class);
    }

    public function getTotalBalance(string $asset)
    {
        try {
            return $this->createQueryBuilder('b')
                ->select('SUM(b.balance) as balance')
                ->where('b.asset = :asset')
                ->setParameter('asset', $asset)
                ->getQuery()
                ->getSingleScalarResult();
        } catch (NoResultException|NonUniqueResultException $e) {
            return 0;
        }
    }

    public function getTotalUserBalances(User $user)
    {
        return $this->createQueryBuilder('b')
            ->select('b.asset')
            ->addSelect('b.contract')
            ->addSelect('SUM(b.balance) as balance')
            ->where('b.userId = :uid')
            ->groupBy('b.userId')
            ->addGroupBy('b.asset')
            ->addGroupBy('b.contract')
            ->orderBy('b.asset')
            ->setParameter('uid', $user->getId())
            ->getQuery()
            ->getArrayResult();
    }

    public function getUserAssetBalances(User $user, string $contract, string $asset)
    {
        return $this->createQueryBuilder('b')
            ->where('b.userId = :uid')
            ->andWhere('b.asset = :asset')
            ->andWhere('b.contract = :contract')
            ->orderBy('b.balance')
            ->setParameters(['uid' => $user->getId(), 'contract' => $contract, 'asset' => $asset])
            ->getQuery()->getArrayResult();
    }
}
