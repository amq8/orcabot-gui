<?php

namespace App\API;

use Exception;

class APIException extends Exception
{
}
