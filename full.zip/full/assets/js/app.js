import '../scss/app.scss';
import {initNavbarBurger} from "./navbar";
import {initModals} from "./modal";

import Vue from "vue";
import ApexCharts from 'apexcharts';
global.ApexCharts = ApexCharts;

import WithdrawModal from '../components/withdraw_modal'
import DepositModal from '../components/deposit_modal'
import InternalTransferModal from '../components/internal_transfer_modal'
import SavingsModal from '../components/savings_modal'

document.addEventListener('DOMContentLoaded', () => {
    if (window.userBalances) {
        initBalanceHandling();
    }

    initNavbarBurger();
    initModals();

    const tabTogglers = document.querySelectorAll('[data-tab-toggle]');
    for (const toggler of tabTogglers) {
        toggler.addEventListener('click', function () {
            for (const tab of document.querySelectorAll('[data-tab]')) {
                if (tab.dataset.tab === this.dataset.tabToggle) {
                    tab.style.display = 'block';
                } else {
                    tab.style.display = 'none';
                }
            }
            for (const t of tabTogglers) {
                t.classList.remove('is-active');
            }
            toggler.classList.add('is-active');
        })
    }
});

global.initPnLChart = function (selector, data, name = 'Profit/Loss') {
    const el = document.querySelector(selector);
    if (!el) return;
    const chart = new ApexCharts(el, {
        series: [{ name, data }],
        chart: {
            type: 'area',
            background: 'transparent',
            height: '350px',
            animations: {
                speed: 300
            }
        },
        colors: ['#0d6129'],
        dataLabels: {enabled: false},
        legend: {show: false},
        tooltip: {
            x: {
                formatter: t => (new Date(t).toLocaleString())
            }
        },
        plotOptions: {
            bar: {
                colors: {
                    ranges: [{
                        from: -Infinity,
                        to: 0,
                        color: '#F15B46'
                    }]
                },
                columnWidth: '80%'
            }
        },
        theme: {
            mode: 'dark'
        },
        stroke: {
            width: 1
        },
        grid: {
            borderColor: '#111',
        },
        xaxis: {
            type: 'datetime',
            labels: {
                datetimeUTC: true
            },
            tooltip: {enabled: false}
        },
        yaxis: {
            forceNiceScale: true,
            tickAmount: 5,
            labels: {
                formatter: function (val) {
                    return Number(val).toFixed(2) + 'USDT'
                }
            }
        }
    });
    void chart.render();
};

function initBalanceHandling()
{
    new Vue({
        el: '#modals-app',
        delimiters: ['[[', ']]'],
        components: { WithdrawModal, DepositModal, InternalTransferModal, SavingsModal }
    })
}