<?php

namespace App\Utils;

class Utils
{
    public const ASSET_DECIMALS = 8;

    public static function formatAsset($number, $asset, $name = false, $displayDecimals = null): ?string
    {
        $baseAmount = self::formatAssetRaw($number);
        if (null === $baseAmount) {
            return null;
        }

        $fmt = number_format($baseAmount, $displayDecimals ?? self::ASSET_DECIMALS);

        if ('0' !== $fmt) {
            $fmt = rtrim($fmt, '0');
            $fmt = rtrim($fmt, localeconv()['decimal_point']);
        }

        return $fmt.($name ? $asset : '');
    }

    public static function formatAssetRaw($number)
    {
        if (!is_numeric($number)) {
            return null;
        }

        return $number / (10 ** self::ASSET_DECIMALS);
    }
}
