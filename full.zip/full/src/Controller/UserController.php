<?php

namespace App\Controller;

use App\API\APIClient;
use App\API\APIException;
use App\Binance\BinanceApiException;
use App\Binance\BinanceClient;
use App\Binance\BinanceClientFactory;
use App\Entity\Balance;
use App\Entity\BinanceAccount;
use App\Entity\User;
use App\Repository\AutoTradeRepository;
use App\Repository\BalanceRepository;
use App\Service\TradeDataService;
use DateTime;
use Exception;
use InvalidArgumentException;
use Psr\Log\LoggerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Exception\InvalidCsrfTokenException;
use Throwable;

class UserController extends AbstractController
{
    /**
     * @Route("/u/dashboard", name="dashboard")
     *
     * @throws Exception
     */
    public function dashboard(
        AutoTradeRepository $autoTradeRepository,
        BalanceRepository $balanceRepository,
        TradeDataService $tds
    ): Response {
        /** @var User $user */
        $user = $this->getUser();

        $allBalances = $balanceRepository->getTotalUserBalances($user);
        $balances = [];
        foreach ($allBalances as $bal) {
            $balances[$bal['contract']][] = $bal;
        }

        return $this->render('user/dashboard.html.twig', [
            'trades' => $autoTradeRepository->getLatestUserTrades($user, 5),
            'balances' => $balances,
            'refCount' => 0, // $refCount,
            'refTotals' => 0, // $refTotals,
            'allTimeData' => $tds->getAllTimeData($user),
            'dailyPnL' => $autoTradeRepository->getDailyUserPnL($user, new DateTime('-1 month 0:00'), new DateTime()),
            'cumulativeStart' => $autoTradeRepository->getCumulativeUserPnL($user, new DateTime('-1 month 0:00')),
        ]);
    }

    /**
     * @Route("/u/trades", name="recent_trades")
     */
    public function trades(AutoTradeRepository $autoTradeRepository, Request $request): Response
    {
        /** @var User $user */
        $user = $this->getUser();

        $trades = $autoTradeRepository->getPaginatedUserTrades($user, $request->query->getInt('page', 1));

        return $this->render('user/trades.html.twig', ['trades' => $trades]);
    }

    /**
     * @Route("/u/unconfirmed", name="unconfirmed")
     */
    public function unconfirmed(): Response
    {
        return $this->render('user/unconfirmed.html.twig');
    }

    /**
     * @Route("/u/api/withdraw", name="user_api_withdraw", methods={"POST"})
     */
    public function withdraw(Request $request, BinanceClient $masterBinance, BinanceClient $withdrawBinance, APIClient $api): Response
    {
        try {
            if (!$this->isCsrfTokenValid('frontend', $request->get('csrfToken'))) {
                throw new InvalidCsrfTokenException();
            }

            $contract = strtoupper($request->request->getAlpha('contract'));
            $asset = strtoupper($request->request->getAlpha('asset'));
            $amountStr = $request->request->get('amount');
            $address = $request->request->get('address');
            $network = $request->request->get('network');

            if (
                empty($asset) || !is_numeric($amountStr) || null === $address ||
                !in_array($contract, ['SPOT', 'FUTURES'], true) ||
                (null !== $network && !in_array($network, ['ETH', 'TRX'], true))
            ) {
                throw new InvalidArgumentException('Invalid request. Please try again later.');
            }

            $amount = (float) $amountStr;

            /** @var User $user */
            $user = $this->getUser();

            $balances = $this->getDoctrine()->getRepository(Balance::class)
                ->getUserAssetBalances($user, $contract, $asset);

            if (empty($balances)) {
                throw new InvalidArgumentException('The chosen asset is not available for withdrawal on your account.');
            }

            $totalBalance = array_sum(array_map(static function ($b) {
                return (float) $b['balance'] / (10 ** 8);
            }, $balances));

            if ($totalBalance < $amount) {
                throw new InvalidArgumentException('The entered amount exceeds your available balance.');
            }

            $withdrawAccBalances = array_column($withdrawBinance->accountInfo()['balances'], null, 'asset');
            $withdrawAccAssetBalance = (float) $withdrawAccBalances[$asset]['free'];

            if ($withdrawAccAssetBalance < $amount) {
                throw new Exception("The requested amount is currently not available for transfer.\n"."Currently available: $withdrawAccAssetBalance$asset");
            }

            $transferred = 0;
            while (count($balances) > 0 && $transferred < $amount) {
                $bal = array_shift($balances);
                $toTransfer = min((float) $bal['balance'] / (10 ** 8), $amount);

                $userAccount = $this->getDoctrine()->getRepository(BinanceAccount::class)->find([
                    'userId' => $user->getId(), 'accountName' => $bal['userAccount'],
                ]);
                if (null === $userAccount) {
                    continue;
                }

                $fromWallet = $this->getWalletType($contract, $asset);
                $masterBinance->universalTransfer($asset, $toTransfer, $user->getEmail(), null, $fromWallet);
                $api->updateAccountBalances($userAccount);
                $transferred += $toTransfer;
            }

            $withdrawBinance->withdraw($asset, $address, $amount, null, null, false, $network);

            $this->addFlash('notice', "$amount$asset have been sent to your wallet.");
        } catch (Throwable $e) {
            $this->addFlash('error', $e->getMessage());
        }

        return $this->redirectToRoute('dashboard');
    }

    /**
     * @Route("/u/api/depositAddr", name="user_api_deposit_address", methods={"GET"})
     */
    public function depositAddr(Request $request, BinanceClient $masterBinance, LoggerInterface $logger): ?Response
    {
        try {
            if (!$this->isCsrfTokenValid('frontend', $request->get('csrfToken'))) {
                throw new InvalidCsrfTokenException();
            }

            $validCoins = ['BTC', 'USDT'];

            $email = $request->get('email');
            $coin = $request->get('asset');
            $network = $request->get('network');

            if (
                empty($email) ||
                !in_array($coin, $validCoins, true) ||
                false === filter_var($email, FILTER_VALIDATE_EMAIL)
            ) {
                return new Response('Invalid request. Please try again later.', 400);
            }

            return new Response($masterBinance->subDepositAddress($email, $coin, $network)['address']);
        } catch (Throwable $e) {
            $logger->error('Could not get deposit address: '.$e->getMessage());

            return new Response('An error occurred, try again later.', 400);
        }
    }

    /**
     * @Route("/u/api/internalTransfer", name="user_api_internal_transfer", methods={"POST"})
     */
    public function internalTransfer(Request $request, BinanceClient $masterBinance, APIClient $api): Response
    {
        try {
            if (!$this->isCsrfTokenValid('frontend', $request->get('csrfToken'))) {
                throw new InvalidCsrfTokenException();
            }

            /** @var User $user */
            $user = $this->getUser();

            $asset = $request->get('asset');
            $amount = $request->get('amount');
            $destination = $request->get('destination');

            if (
                null === $asset || !is_numeric($amount) || empty($user->getEmail()) ||
                !in_array($destination, ['SPOT', 'FUTURES'], true)
            ) {
                throw new InvalidArgumentException('Invalid request. Please try again later.');
            }

            $source = 'FUTURES' === $destination ? 'SPOT' : 'FUTURES';

            $fromWallet = $this->getWalletType($source, $asset);
            $toWallet = $this->getWalletType($destination, $asset);

            $masterBinance->universalTransfer($asset, $amount, $user->getEmail(), $user->getEmail(), $fromWallet, $toWallet);
            sleep(1);
            $accounts = $this->getDoctrine()->getRepository(BinanceAccount::class)->findBy(['userId' => $user->getId()]);
            foreach ($accounts as $account) {
                $api->updateAccountBalances($account);
            }

            $this->addFlash('notice', 'Internal transfer requested. Your balance will update shortly.');
        } catch (Throwable $e) {
            $this->addFlash('error', $e->getMessage());
        }

        return $this->redirectToRoute('dashboard');
    }

    /**
     * @Route("/u/api/updateBalances", name="user_api_update_balances", methods={"POST"})
     *
     * @throws APIException
     */
    public function updateBalances(APIClient $api): Response
    {
        /** @var User $user */
        $user = $this->getUser();
        $accounts = $this->getDoctrine()->getRepository(BinanceAccount::class)->findBy(['userId' => $user->getId()]);
        foreach ($accounts as $account) {
            $api->updateAccountBalances($account);
        }

        return $this->json([]);
    }

    /**
     * @Route("/u/api/updateTradingStatus", name="user_api_update_trading_status", methods={"POST"})
     *
     * @throws APIException
     */
    public function updateTradingStatus(Request $request, APIClient $api): Response
    {
        /** @var User $user */
        $user = $this->getUser();
        if (!$request->request->has('contract') || !$request->request->has('paused')) {
            throw new BadRequestHttpException();
        }
        $contract = $request->request->get('contract');
        $paused = $request->request->getBoolean('paused');
        $api->updateTradingStatus($user, $contract, $paused);

        return $this->json([]);
    }

    /**
     * @Route("/u/api/savings/account", name="user_api_savings_account", methods={"GET"})
     */
    public function savingsAccount(BinanceClientFactory $binanceFactory): Response
    {
        /** @var User $user */
        $user = $this->getUser();
        $account = $this->getDoctrine()->getRepository(BinanceAccount::class)
            ->findOneBy(['userId' => $user->getId()]);

        try {
            if ($account) {
                $client = $binanceFactory->create($account);

                return $this->json($client->getLendingAccountData());
            }

            return $this->json(['error' => 'No Binance account found']);
        } catch (Exception $e) {
            return $this->json(['error' => $e->getMessage()]);
        }
    }

    /**
     * @Route("/u/api/savings/position/{asset}", name="user_api_savings_position", methods={"GET"})
     */
    public function savingsPosition(string $asset, BinanceClientFactory $binanceFactory): Response
    {
        /** @var User $user */
        $user = $this->getUser();
        $account = $this->getDoctrine()->getRepository(BinanceAccount::class)
            ->findOneBy(['userId' => $user->getId()]);

        try {
            if ($account) {
                $client = $binanceFactory->create($account);
                $position = $client->getFlexibleProductPosition($asset);

                return $this->json($position[0] ?? []);
            }

            return $this->json(['error' => 'No Binance account found']);
        } catch (Exception $e) {
            return $this->json(['error' => $e->getMessage()]);
        }
    }

    /**
     * @Route("/u/api/savings/transfer", name="user_api_savings_transfer", methods={"POST"})
     */
    public function savingsTransfer(Request $request, BinanceClientFactory $binanceFactory): Response
    {
        if (!$this->isCsrfTokenValid('frontend', $request->get('csrfToken'))) {
            throw new InvalidCsrfTokenException();
        }

        $transferMode = $request->request->get('transferMode');
        $transferAsset = $request->request->get('transferAsset');
        $transferAmount = $request->request->get('transferAmount');
        $redemptionType = $request->request->get('redemptionType');

        /** @var User $user */
        $user = $this->getUser();
        $account = $this->getDoctrine()->getRepository(BinanceAccount::class)
            ->findOneBy(['userId' => $user->getId()]);

        if (
            !$account ||
            !$transferAsset ||
            !$transferAmount ||
            ('redeem' === $transferMode && !in_array($redemptionType, ['NORMAL', 'FAST'], true)) ||
            !in_array($transferMode, ['purchase', 'redeem'], true)
        ) {
            throw $this->createNotFoundException();
        }

        $client = $binanceFactory->create($account);

        try {
            if ('purchase' === $transferMode) {
                $result = $client->purchaseFlexibleProduct($transferAsset.'001', $transferAmount);
                $this->addFlash('notice', sprintf(
                    'Purchase order for %s%s has been sent. (Binance Purchase ID: %s)',
                    $transferAmount, $transferAsset, $result['purchaseId'],
                ));
            } else {
                $client->redeemFlexibleProduct($transferAsset.'001', $transferAmount, $redemptionType);
                $this->addFlash('notice', sprintf(
                    'Redemption request for %s%s has been sent.',
                    $transferAmount, $transferAsset
                ));
            }
        } catch (BinanceApiException $e) {
            $this->addFlash('error', 'Error: '.$e->getMessage());
        }

        return $this->redirectToRoute('dashboard');
    }

    private function getWalletType(string $contract, string $asset): string
    {
        if ('FUTURES' === $contract) {
            return 'USDT' === $asset ? 'USDT_FUTURE' : 'COIN_FUTURE';
        }

        return 'SPOT';
    }
}
