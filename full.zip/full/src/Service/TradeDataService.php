<?php

namespace App\Service;

use App\Entity\User;
use App\Repository\AutoTradeRepository;

class TradeDataService
{
    private $autoTradeRepository;

    public function __construct(AutoTradeRepository $autoTradeRepository)
    {
        $this->autoTradeRepository = $autoTradeRepository;
    }

    public function getDailyTotals()
    {
        $result = $this->autoTradeRepository->createQueryBuilder('t')
            ->select('t.quoteAsset')
            ->addSelect("SUM(CASE WHEN t.result = 'TAKE_PROFIT' THEN t.net ELSE 0 END) as takeProfit")
            ->addSelect("SUM(CASE WHEN t.result = 'STOP_LOSS' THEN t.net ELSE 0 END) as stopLoss")
            // ->addSelect("SUM(CASE WHEN t.side = 'BUY' THEN t.net ELSE 0 END) as long")
            // ->addSelect("SUM(CASE WHEN t.side = 'SELL' THEN t.net ELSE 0 END) as short")
            ->addSelect('SUM(t.net) as total')
            ->addSelect('COUNT(t) as count')
            ->where('t.test = false')
            ->andWhere("t.status = 'CLOSED'")
            ->andWhere("t.result != 'CANCELLED'")
            ->andWhere("t.closedAt >= DATE_SUB(CURRENT_DATE(), 24, 'hour')")
            ->groupBy('t.quoteAsset')
            ->getQuery()->getArrayResult();
        $result = array_column($result, null, 'quoteAsset');
        foreach (['BTC', 'ETH', 'USDT'] as $asset) {
            if (!array_key_exists($asset, $result)) {
                $result[$asset] = [
                    'quoteAsset' => $asset,
                    'takeProfit' => 0,
                    'stopLoss' => 0,
                    'long' => 0,
                    'short' => 0,
                    'total' => 0,
                    'count' => 0,
                ];
            }
        }

        return $result;
    }

    public function getAllTimeData(User $user = null)
    {
        $qb = $this->autoTradeRepository->createQueryBuilder('t')
            ->select('t.quoteAsset')
            ->addSelect('SUM(t.net) as total')
            ->addSelect('COUNT(t) as count')
            ->where('t.test = false')
            ->andWhere("t.status = 'CLOSED'")
            ->andWhere("t.result != 'CANCELLED'")
            ->groupBy('t.quoteAsset');
        if (null != $user) {
            $qb = $qb->andWhere('t.userId = :uid')->setParameter('uid', $user->getId());
        }

        return array_column($qb->getQuery()->getArrayResult(), null, 'quoteAsset');
    }
}
