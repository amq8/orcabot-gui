<?php

namespace App\Security;

use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\JWT;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\Flash\FlashBag;
use Symfony\Component\Routing\RouterInterface;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\Exception\CustomUserMessageAuthenticationException;
use Symfony\Component\Security\Http\Authenticator\AbstractAuthenticator;
use Symfony\Component\Security\Http\Authenticator\Passport\Badge\UserBadge;
use Symfony\Component\Security\Http\Authenticator\Passport\Passport;
use Symfony\Component\Security\Http\Authenticator\Passport\SelfValidatingPassport;
use Symfony\Contracts\Service\Attribute\Required;

class TelegramAuthenticator extends AbstractAuthenticator
{
    #[Required] public RouterInterface $router;
    #[Required] public EntityManagerInterface $entityManager;

    private $jwtSecret;

    public function __construct(string $jwtSecret)
    {
        $this->jwtSecret = $jwtSecret;
    }

    public function supports(Request $request): ?bool
    {
        return 'link' === $request->attributes->get('_route') && $request->isMethod('GET');
    }

    public function authenticate(Request $request): Passport
    {
        if (empty($request->query->get('token'))) {
            throw new AuthenticationException();
        }

        try {
            $data = JWT::decode($request->query->get('token'), $this->jwtSecret, ['HS256']);
        } catch (ExpiredException) {
            throw new CustomUserMessageAuthenticationException('This login link has expired. Please create a new one and try again.');
        }

        if (empty($data->sub) || empty($data->username)) {
            throw new AuthenticationException();
        }

        $passport = new SelfValidatingPassport(new UserBadge((string) $data->sub, function ($id) use ($data) {
            $user = $this->entityManager->getRepository(User::class)->find($id);
            if (null === $user) {
                throw new NewUserException(['id' => $id, 'username' => $data->username]);
            }

            return $user;
        }));
        $passport->setAttribute('username', $data->username);

        return $passport;
    }

    public function onAuthenticationSuccess(Request $request, TokenInterface $token, string $firewallName): ?Response
    {
        return new RedirectResponse($this->router->generate('dashboard'));
    }

    public function onAuthenticationFailure(Request $request, AuthenticationException $exception): ?Response
    {
        if ($exception instanceof NewUserException) {
            $request->getSession()->set('credentials', $exception->getCredentials());

            return new RedirectResponse($this->router->generate('register'));
        }

        /** @var FlashBag $flashBag */
        $flashBag = $request->getSession()->getBag('flashes');
        if ($exception instanceof CustomUserMessageAuthenticationException) {
            $flashBag->add('error', $exception->getMessage());
        } else {
            $flashBag->add('error', 'Invalid login link. Please create a new link and try again.');
        }

        return new RedirectResponse($this->router->generate('index'));
    }
}
