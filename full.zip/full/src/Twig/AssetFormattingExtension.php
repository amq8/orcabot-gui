<?php

namespace App\Twig;

use App\Utils\Utils;
use Twig\Extension\AbstractExtension;
use Twig\TwigFilter;

class AssetFormattingExtension extends AbstractExtension
{
    public function getFilters()
    {
        return [
            new TwigFilter('asset', [Utils::class, 'formatAsset']),
            new TwigFilter('assetRaw', [Utils::class, 'formatAssetRaw']),
        ];
    }
}
