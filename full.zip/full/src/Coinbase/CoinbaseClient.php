<?php

namespace App\Coinbase;

use DateTime;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Throwable;

class CoinbaseClient
{
    private $httpClient;

    public const BASE_URL = 'https://api.pro.coinbase.com';

    public function __construct(HttpClientInterface $httpClient)
    {
        $this->httpClient = $httpClient;
    }

    /**
     * @return array
     *
     * @throws Throwable
     */
    public function getHistoricRates(string $product, DateTime $start, DateTime $end, int $granularity)
    {
        $result = [];
        $diffHours = ceil(($end->getTimestamp() - $start->getTimestamp()) / 3600);
        $nextEnd = clone $end;
        while ($diffHours > 0) {
            $delta = min(300, $diffHours);
            $nextStart = max($start, DateTime::createFromFormat('U', (string) ($nextEnd->getTimestamp() - $delta * 3600)));
            $response = $this->httpClient->request('GET', self::BASE_URL.'/products/'.$product.'/candles', [
                'query' => [
                    'granularity' => $granularity,
                    'start' => $nextStart->format(DateTime::ATOM),
                    'end' => $nextEnd->format(DateTime::ATOM),
                ],
            ])->toArray(false);

            foreach ($response as $row) {
                $result[] = [
                    'time' => $row[0],
                    'low' => $row[1],
                    'high' => $row[2],
                    'open' => $row[3],
                    'close' => $row[4],
                    'volume' => $row[5],
                ];
            }
            $nextEnd = clone $nextStart;
            $diffHours -= $delta;
        }

        return $result;
    }
}
