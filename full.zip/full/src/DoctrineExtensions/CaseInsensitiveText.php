<?php

namespace App\DoctrineExtensions;

use Doctrine\DBAL\Exception;
use Doctrine\DBAL\Platforms\AbstractPlatform;
use Doctrine\DBAL\Types\TextType;

final class CaseInsensitiveText extends TextType
{
    private const CITEXT = 'citext';

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return self::CITEXT;
    }

    /**
     * {@inheritdoc}
     *
     * @throws Exception
     */
    public function getSQLDeclaration(array $fieldDeclaration, AbstractPlatform $platform): string
    {
        return $platform->getDoctrineTypeMapping(self::CITEXT);
    }
}
