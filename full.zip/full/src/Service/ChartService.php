<?php

namespace App\Service;

use DateTime;
use Exception;

class ChartService
{
    /**
     * @throws Exception
     */
    public function buildChartResult(array $queryResult,
                                     array $cols,
                                     DateTime $from,
                                     DateTime $to,
                                     ?string $reindexBy = null,
                                     array $reindexValues = []): array
    {
        $result = [];
        if ((null !== $reindexBy && empty($reindexValues)) || (null === $reindexBy && !empty($reindexValues))) {
            throw new Exception('Either neither or both reindexBy and reindexValues must be specified');
        }
        if (!empty($reindexValues)) {
            foreach ($reindexValues as $val) {
                $result[$val] = [];
                foreach ($cols as $key) {
                    $result[$val][$key] = ['total' => 0, 'daily' => []];
                }
            }
        } else {
            foreach ($cols as $key) {
                $result[$key] = ['total' => 0, 'daily' => []];
            }
        }
        foreach ($cols as $key) {
            foreach ($queryResult as $row) {
                $r = &$result;
                if (null !== $reindexBy) {
                    $r = &$result[$row[$reindexBy]];
                }
                $val = (int) $row[$key];
                $r[$key]['total'] += $val;
                $r[$key]['daily'][(int) strtotime($row['date']) * 1000] = $val;
            }
            if (null === $reindexBy) {
                $this->fillMissingDailyEntries($result[$key]['daily'], $from, $to);
            } else {
                foreach ($result as &$r) {
                    $this->fillMissingDailyEntries($r[$key]['daily'], $from, $to);
                }
            }
        }

        return $result;
    }

    public function fillMissingDailyEntries(&$d, $from, $to): void
    {
        for ($t = $from->getTimestamp(); $t < $to->getTimestamp(); $t += 86400) {
            if (empty($d[$t * 1000])) {
                $d[$t * 1000] = 0;
            }
        }
        ksort($d);
    }
}
