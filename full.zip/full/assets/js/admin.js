import ApexCharts from 'apexcharts';
global.ApexCharts = ApexCharts;

function initChart(id, series, colors, overrides = {}) {
    const el = document.querySelector(id);
    if (!el) return;
    const chart = new ApexCharts(el, Object.assign({
        annotations: {
            yaxis: [
                {
                    y: 0,
                    strokeDashArray: 0,
                    borderColor: '#ddd'
                }
            ]
        },
        series,
        chart: {
            type: 'area',
            background: 'transparent',
            height: '400px',
            animations: {
                speed: 300
            }
        },
        colors,
        dataLabels: {enabled: false},
        legend: {show: false},
        tooltip: {
            x: {
                formatter: t => (new Date(t).toLocaleString(undefined, {timeZone: 'UTC'}))
            }
        },
        theme: {
            mode: 'dark'
        },
        stroke: {
            width: 1
        },
        grid: {
            borderColor: '#111',
        },
        xaxis: {
            type: 'datetime',
            labels: {
                datetimeUTC: true
            },
            tooltip: {enabled: false}
        },
        yaxis: {
            forceNiceScale: true,
            tickAmount: 10,
            labels: {
                formatter: function (val) {
                    return Number(val).toFixed(4) + '%'
                }
            }
        }
    }, overrides));
    chart.render();
}

global.initChart = initChart;

global.initCoinbasePremiumChart = function (data) {
    initChart('#coinbase-premium-chart', [
        {name: 'Coinbase Price Difference', data: data['value'], 'type': 'area'},
        {name: 'Coinbase Premium Index', data: data['percent'], 'type': 'line'}
    ], ['#2b71b1', '#ffffff'], {
        yaxis: [
            {
                title: { text: 'Coinbase Price Difference' },
                opposite: true,
                labels: {
                    formatter: function (val) {
                        return Number(val).toFixed(2) + '$'
                    }
                }
            },
            {
                title: { text: 'Coinbase Premium Index' },
                labels: {
                    formatter: function (val) {
                        return Number(val).toFixed(2) + '%'
                    }
                }
            }
        ],
        fill: {
            type: 'solid',
            opacity: [0.35, 1],
        },
    });
};