<?php

namespace App\Binance;

use Exception;
use Psr\Log\LoggerInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Throwable;

class BinanceClient
{
    private $apiKey;
    private $secretKey;
    private $timeOffset = 0;

    private $baseUrl = 'https://api.binance.com';

    private HttpClientInterface $httpClient;
    private LoggerInterface $logger;

    public function __construct(HttpClientInterface $httpClient, LoggerInterface $logger, string $apiKey = null, string $secretKey = null)
    {
        $this->apiKey = $apiKey;
        $this->secretKey = $secretKey;
        $this->httpClient = $httpClient;
        $this->logger = $logger;
    }

    /**
     * Perform a Binance API call.
     *
     * @throws BinanceApiException
     */
    private function apiCall(string $url, string $method = 'GET', array $params = [], bool $signed = false, string $expectResultParameter = null): array
    {
        try {
            $endpoint = $this->baseUrl.$url;

            if ($signed) {
                if (empty($this->apiKey) || empty($this->secretKey)) {
                    throw new Exception('Cannot execute a signed API call without credentials');
                }

                $ts = (microtime(true) * 1000) + $this->timeOffset;
                $params['timestamp'] = number_format($ts, 0, '.', '');

                $query = http_build_query($params);

                $signature = hash_hmac('sha256', $query, $this->secretKey);
                $params['signature'] = $signature;
            }

            $response = $this->httpClient->request($method, $endpoint, [
                'headers' => [
                    'X-MBX-APIKEY' => $this->apiKey,
                ],
                'query' => $params,
            ]);

            $result = $response->toArray(false);

            $this->logger->info(sprintf('Binance: %s %s %s: %s', $method, $url, json_encode($params), json_encode($result)));

            if (isset($result['msg']) || (null !== $expectResultParameter && !isset($result[$expectResultParameter]))) {
                // API error
                throw new Exception();
            }

            return $result;
        } catch (Throwable $e) {
            throw new BinanceApiException($url, !empty($result) ? $result : $e->getMessage());
        }
    }

    /**
     * Sync the time with the server by storing the time offset.
     *
     * @throws Exception
     */
    public function useServerTime(): void
    {
        $request = $this->apiCall('/api/v1/time');
        if (isset($request['serverTime'])) {
            $this->timeOffset = $request['serverTime'] - (microtime(true) * 1000);
        }
    }

    /**
     * Get current account information.
     *
     * @throws BinanceApiException
     */
    public function accountInfo(): array
    {
        return $this->apiCall('/api/v3/account', 'GET', [], true);
    }

    /**
     * Get kline/candlestick chart data.
     *
     * @throws Exception
     */
    public function klines(
        string $symbol,
        string $interval,
        int $startTime = null,
        int $endTime = null,
        int $limit = 1000
    ): array {
        $params = [
            'symbol' => $symbol,
            'interval' => $interval,
            'limit' => $limit,
        ];
        if (null !== $startTime) {
            $params['startTime'] = $startTime;
        }
        if (null !== $endTime) {
            $params['endTime'] = $endTime;
        }

        return $this->apiCall('/api/v3/klines', 'GET', $params);
    }

    /**
     * Withdraw from the spot wallet to an external address.
     *
     * @throws BinanceApiException
     */
    public function withdraw(
        string $asset,
        string $address,
        float $amount,
        string $addressTag = null,
        string $addressName = null,
        bool $transactionFeeFlag = false,
        string $network = null
    ): array {
        $params = [
            'coin' => $asset,
            'address' => $address,
            'amount' => $amount,
            'transactionFeeFlag' => $transactionFeeFlag,
        ];
        if (null !== $addressName) {
            $params['name'] = str_replace(' ', '%20', $addressName); // does not work, invalid signature
        }
        if (null !== $addressTag) {
            $params['addressTag'] = $addressTag;
        }
        if (null !== $network) {
            $params['network'] = $network;
        }

        return $this->apiCall('/sapi/v1/capital/withdraw/apply', 'POST', $params, true, 'id');
    }

    /**
     * Transfer between spot and futures wallet.
     *
     * @throws Exception
     */
    public function futuresTransfer(string $asset, float $amount, int $type): array
    {
        return $this->apiCall('/sapi/v1/futures/transfer', 'POST', [
            'asset' => $asset,
            'amount' => $amount,
            'type' => $type,
        ], true, 'tranId');
    }

    /**
     * Create subaccount.
     *
     * @throws BinanceApiException
     */
    public function createSubAccount(string $tag): array
    {
        return $this->apiCall('/sapi/v1/sub-account/virtualSubAccount', 'POST', [
            'subAccountString' => $tag,
        ], true, 'email');
    }

    /**
     * Enable margin trading for subaccount.
     *
     * @throws BinanceApiException
     */
    public function enableSubAccountMargin(string $email): array
    {
        return $this->apiCall('/sapi/v1/sub-account/margin/enable', 'POST', [
            'email' => $email,
        ], true, 'isMarginEnabled');
    }

    /**
     * Enable futures trading for subaccount.
     *
     * @throws BinanceApiException
     */
    public function enableSubAccountFutures(string $email): array
    {
        return $this->apiCall('/sapi/v1/sub-account/futures/enable', 'POST', [
            'email' => $email,
        ], true, 'isFuturesEnabled');
    }

    /**
     * Transfer from subaccount (current account) to master.
     *
     * @throws BinanceApiException
     */
    public function subDepositAddress(string $email, string $coin, string $network = null): array
    {
        $params = [
            'email' => $email,
            'coin' => $coin,
        ];

        if (null !== $network) {
            $params['network'] = $network;
        }

        return $this->apiCall('/sapi/v1/capital/deposit/subAddress', 'GET', $params, true, 'address');
    }

    /**
     * Universal asset transfer for subaccounts
     * Transfer from master account by default if fromEmail is not sent.
     * Transfer to master account by default if toEmail is not sent.
     * Transfer between futures accounts is not supported.
     *
     * @throws BinanceApiException
     */
    public function universalTransfer(
        string $asset,
        float $amount,
        ?string $fromEmail = null,
        ?string $toEmail = null,
        string $fromAccountType = 'SPOT',
        string $toAccountType = 'SPOT'
    ): array {
        if ($fromEmail === $toEmail && $fromAccountType === $toAccountType) {
            return [];
        }

        $data = [
            'asset' => $asset,
            'amount' => $amount,
            'fromAccountType' => $fromAccountType,
            'toAccountType' => $toAccountType,
        ];

        if ($fromEmail) {
            $data['fromEmail'] = $fromEmail;
        }

        if ($toEmail) {
            $data['toEmail'] = $toEmail;
        }

        return $this->apiCall('/sapi/v1/sub-account/universalTransfer', 'POST', $data, true, 'txnId');
    }

    /**
     * Get lending (savings) account data.
     *
     * @throws BinanceApiException
     */
    public function getLendingAccountData(): array
    {
        return $this->apiCall('/sapi/v1/lending/union/account', 'GET', [], true, 'positionAmountVos');
    }

    /**
     * Get subscribable flexible product list.
     *
     * @throws BinanceApiException
     */
    public function getSubscribableFlexibleProductList(): array
    {
        return $this->apiCall('/sapi/v1/lending/daily/product/list', 'GET', [], true);
    }

    /**
     * Get Flexible Product Position.
     *
     * @throws BinanceApiException
     */
    public function getFlexibleProductPosition(string $asset): array
    {
        return $this->apiCall('/sapi/v1/lending/daily/token/position', 'GET', ['asset' => $asset], true);
    }

    /**
     * Purchase Flexible Product.
     *
     * @throws BinanceApiException
     */
    public function purchaseFlexibleProduct(string $productId, string $amount): array
    {
        return $this->apiCall('/sapi/v1/lending/daily/purchase', 'POST', [
            'productId' => $productId,
            'amount' => $amount,
        ], true, 'purchaseId');
    }

    /**
     * Redeem Flexible Product.
     *
     * @param string $redeemMode NORMAL|FAST
     *
     * @throws BinanceApiException
     */
    public function redeemFlexibleProduct(string $productId, string $amount, string $redeemMode): array
    {
        return $this->apiCall('/sapi/v1/lending/daily/redeem', 'POST', [
            'productId' => $productId,
            'amount' => $amount,
            'type' => $redeemMode,
        ], true);
    }

    /**
     * @throws BinanceApiException
     */
    public function getAllCoinInfo(): array
    {
        return $this->apiCall('/sapi/v1/capital/config/getall', 'GET', [], true);
    }
}
