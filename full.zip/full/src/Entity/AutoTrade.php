<?php

namespace App\Entity;

use App\Repository\AutoTradeRepository;
use DateTimeInterface;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=AutoTradeRepository::class)
 */
class AutoTrade
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="integer", name="""userId""")
     */
    private $userId;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    private $test;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $symbol;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $side;

    /**
     * @ORM\Column(type="bigint", nullable=true)
     */
    private $amount;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $status;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    private $paused;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $result;

    /**
     * @ORM\Column(type="bigint", nullable=true, name="""openPrice""")
     */
    private $openPrice;

    /**
     * @ORM\Column(type="bigint", nullable=true, name="""closePrice""")
     */
    private $closePrice;

    /**
     * @ORM\Column(type="bigint", nullable=true)
     */
    private $net;

    /**
     * @ORM\Column(type="string", length=255, name="""orderType""")
     */
    private $orderType;

    /**
     * @ORM\Column(type="string", length=255, nullable=true, name="""quoteAsset""")
     */
    private $quoteAsset;

    /**
     * @ORM\Column(type="datetime", nullable=true, name="""openedAt""")
     */
    private $openedAt;

    /**
     * @ORM\Column(type="datetime", nullable=true, name="""closedAt""")
     */
    private $closedAt;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUserId(): ?User
    {
        return $this->userId;
    }

    public function setUserId(?User $userId): self
    {
        $this->userId = $userId;

        return $this;
    }

    public function getTest(): ?bool
    {
        return $this->test;
    }

    public function setTest(?bool $test): self
    {
        $this->test = $test;

        return $this;
    }

    public function getSymbol(): ?string
    {
        return $this->symbol;
    }

    public function setSymbol(string $symbol): self
    {
        $this->symbol = $symbol;

        return $this;
    }

    public function getAmount(): ?string
    {
        return $this->amount;
    }

    public function setAmount(?string $amount): self
    {
        $this->amount = $amount;

        return $this;
    }

    public function getSide(): ?string
    {
        return $this->side;
    }

    public function setSide(string $side): self
    {
        $this->side = $side;

        return $this;
    }

    public function getStatus(): ?string
    {
        return $this->status;
    }

    public function setStatus(string $status): self
    {
        $this->status = $status;

        return $this;
    }

    public function getPaused(): ?bool
    {
        return $this->paused;
    }

    public function setPaused(?bool $paused): self
    {
        $this->paused = $paused;

        return $this;
    }

    public function getResult(): ?string
    {
        return $this->result;
    }

    public function setResult(?string $result): self
    {
        $this->result = $result;

        return $this;
    }

    public function getOpenPrice(): ?string
    {
        return $this->openPrice;
    }

    public function setOpenPrice(?string $openPrice): self
    {
        $this->openPrice = $openPrice;

        return $this;
    }

    public function getClosePrice(): ?string
    {
        return $this->closePrice;
    }

    public function setClosePrice(?string $closePrice): self
    {
        $this->closePrice = $closePrice;

        return $this;
    }

    public function getNet(): ?string
    {
        return $this->net;
    }

    public function setNet(?string $net): self
    {
        $this->net = $net;

        return $this;
    }

    public function getOrderType(): ?string
    {
        return $this->orderType;
    }

    public function setOrderType(string $orderType): self
    {
        $this->orderType = $orderType;

        return $this;
    }

    public function getQuoteAsset(): ?string
    {
        return $this->quoteAsset;
    }

    public function setQuoteAsset(?string $quoteAsset): self
    {
        $this->quoteAsset = $quoteAsset;

        return $this;
    }

    public function getClosedAt(): ?DateTimeInterface
    {
        return $this->closedAt;
    }

    public function setClosedAt(?DateTimeInterface $closedAt): self
    {
        $this->closedAt = $closedAt;

        return $this;
    }

    public function getOpenedAt(): ?DateTimeInterface
    {
        return $this->openedAt;
    }

    public function setOpenedAt(?DateTimeInterface $openedAt): self
    {
        $this->openedAt = $openedAt;

        return $this;
    }

    public function getFormattedStatus(): ?string
    {
        if (!$this->getStatus()) {
            return null;
        }

        $statusFmt = [
            'OPEN' => ['name' => 'Open', 'class' => 'is-primary'],
            'CLOSED' => ['name' => 'Closed', 'class' => 'is-dark'],
            'PENDING' => ['name' => 'Pending', 'class' => 'is-info'],
        ][$this->getStatus()];

        return sprintf('<span class="tag %s">%s</span>', $statusFmt['class'], $statusFmt['name']);
    }

    public function getFormattedResult(): ?string
    {
        if (!$this->getResult()) {
            return null;
        }

        $statusFmt = [
            'TAKE_PROFIT' => ['name' => 'Take Profit', 'class' => 'is-primary'],
            'STOP_LOSS' => ['name' => 'Stop Loss', 'class' => 'is-danger'],
            'CANCELLED' => ['name' => 'Cancelled', 'class' => 'is-dark'],
            'TIMEOUT' => ['name' => 'Timeout', 'class' => 'is-dark'],
        ][$this->getResult()];

        return sprintf('<span class="tag %s">%s</span>', $statusFmt['class'], $statusFmt['name']);
    }
}
