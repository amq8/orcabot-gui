<?php

namespace App\Entity;

use App\Repository\BinanceAccountRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=BinanceAccountRepository::class)
 */
class BinanceAccount
{
    /**
     * @ORM\Id()
     * @ORM\Column(type="integer", name="`userId`")
     */
    private $userId;

    /**
     * @ORM\Id()
     * @ORM\Column(type="text", name="`accountName`")
     */
    private $accountName;

    /**
     * @ORM\Column(type="text", name="`apiKey`")
     */
    private $apiKey;

    /**
     * @ORM\Column(type="text", name="`secretKey`")
     */
    private $secretKey;

    /**
     * @ORM\Column(type="string", name="`subAccountId`")
     */
    private $subAccountId;

    /**
     * @ORM\Column(type="string", name="`copyFromUserId`")
     */
    private $copyFromUserId;

    /**
     * @ORM\Column(type="string", name="`copyFromAccountName`")
     */
    private $copyFromAccountName;

    public function getUserId(): ?int
    {
        return $this->userId;
    }

    public function setUserId(int $userId): self
    {
        $this->userId = $userId;

        return $this;
    }

    public function getAccountName(): ?string
    {
        return $this->accountName;
    }

    public function setAccountName(string $accountName): self
    {
        $this->accountName = $accountName;

        return $this;
    }

    public function getApiKey(): ?string
    {
        return $this->apiKey;
    }

    public function setApiKey(string $apiKey): self
    {
        $this->apiKey = $apiKey;

        return $this;
    }

    public function getSecretKey(): ?string
    {
        return $this->secretKey;
    }

    public function setSecretKey(string $secretKey): self
    {
        $this->secretKey = $secretKey;

        return $this;
    }

    public function getSubAccountId(): ?string
    {
        return $this->subAccountId;
    }

    public function setSubAccountId(?string $subAccountId): self
    {
        $this->subAccountId = $subAccountId;

        return $this;
    }

    public function getCopyFromUserId(): ?string
    {
        return $this->copyFromUserId;
    }

    public function setCopyFromUserId(?string $copyFromUserId): self
    {
        $this->copyFromUserId = $copyFromUserId;

        return $this;
    }

    public function getCopyFromAccountName(): ?string
    {
        return $this->copyFromAccountName;
    }

    public function setCopyFromAccountName(?string $copyFromAccountName): self
    {
        $this->copyFromAccountName = $copyFromAccountName;

        return $this;
    }
}
