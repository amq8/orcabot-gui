<?php

namespace App\Security;

use App\Entity\User;
use Firebase\JWT\JWT;

class UserTokenService
{
    private string $jwtSecret;

    public function __construct(string $jwtSecret)
    {
        $this->jwtSecret = $jwtSecret;
    }

    public function generateToken(User $user): ?string
    {
        if (null === $user->getId()) {
            return null;
        }

        return JWT::encode(['sub' => $user->getId(), 'username' => $user->getUsername()], $this->jwtSecret);
    }
}
