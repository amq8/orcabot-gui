<?php

namespace App\Binance;

use Exception;

class BinanceApiException extends Exception
{
    private string $method;
    private $data;

    public function __construct(string $method, $data)
    {
        parent::__construct($method.': '.json_encode($data));
        $this->method = $method;
        $this->data = $data;
    }

    public function getMethod(): string
    {
        return $this->method;
    }

    public function setMethod(string $method): void
    {
        $this->method = $method;
    }

    public function getData()
    {
        return $this->data;
    }

    public function setData($data): void
    {
        $this->data = $data;
    }
}
