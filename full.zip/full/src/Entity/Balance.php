<?php

namespace App\Entity;

use App\Repository\BalanceRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=BalanceRepository::class)
 */
class Balance
{
    /**
     * @ORM\Id()
     * @ORM\Column(type="integer", name="`userId`")
     */
    private $userId;

    /**
     * @ORM\Id()
     * @ORM\Column(type="text", name="`userAccount`")
     */
    private $userAccount;

    /**
     * @ORM\Id()
     * @ORM\Column(type="text")
     */
    private $contract;

    /**
     * @ORM\Id()
     * @ORM\Column(type="text")
     */
    private $asset;

    /**
     * @ORM\Column(type="bigint")
     */
    private $balance;

    public function getUserId(): ?int
    {
        return $this->userId;
    }

    public function setUserId(int $userId): self
    {
        $this->userId = $userId;

        return $this;
    }

    public function getUserAccount(): ?string
    {
        return $this->userAccount;
    }

    public function setUserAccount(string $userAccount): self
    {
        $this->userAccount = $userAccount;

        return $this;
    }

    public function getContract(): ?string
    {
        return $this->contract;
    }

    public function setContract(string $contract): self
    {
        $this->contract = $contract;

        return $this;
    }

    public function getAsset(): ?string
    {
        return $this->asset;
    }

    public function setAsset(string $asset): self
    {
        $this->asset = $asset;

        return $this;
    }

    public function getBalance(): ?string
    {
        return $this->balance;
    }

    public function setBalance(string $balance): self
    {
        $this->balance = $balance;

        return $this;
    }
}
