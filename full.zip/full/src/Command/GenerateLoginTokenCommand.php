<?php

namespace App\Command;

use App\Entity\User;
use App\Repository\UserRepository;
use App\Security\UserTokenService;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

class GenerateLoginTokenCommand extends Command
{
    protected static $defaultName = 'app:generateLoginToken';

    private UserTokenService $userTokenService;
    private $userRepository;

    public function __construct(UserTokenService $userTokenService, UserRepository $userRepository)
    {
        parent::__construct();
        $this->userTokenService = $userTokenService;
        $this->userRepository = $userRepository;
    }

    protected function configure()
    {
        $this
            ->setDescription('Generate a login link for a specific user')
            ->addArgument('username', InputArgument::REQUIRED, 'Username of the user to login as');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $username = $input->getArgument('username');

        /** @var User|null $user */
        $user = $this->userRepository->findOneBy(['username' => $username]);

        if (null === $user) {
            $io->error('User '.$username.' not found.');

            return 1;
        }

        $io->writeln($this->userTokenService->generateToken($user));

        return 0;
    }
}
