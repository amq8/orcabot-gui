<?php

namespace App\API;

use App\Entity\BinanceAccount;
use App\Entity\User;
use Psr\Log\LoggerInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Symfony\Contracts\Service\Attribute\Required;
use Throwable;

class APIClient
{
    private string $baseUrl;
    private string $secret;

    #[Required] public HttpClientInterface $httpClient;
    #[Required] public LoggerInterface $logger;

    public function __construct(string $baseUrl, string $secret)
    {
        $this->baseUrl = $baseUrl;
        $this->secret = $secret;
    }

    /**
     * @throws APIException
     */
    public function updateAccountBalances(BinanceAccount $account)
    {
        try {
            $response = $this->httpClient->request('POST', $this->baseUrl.'/updateBalances', [
                'query' => [
                    'userId' => $account->getUserId(),
                    'accountName' => $account->getAccountName(),
                ],
                'headers' => [
                    'Authorization' => 'Bearer '.$this->secret,
                    'Content-Type' => 'text/plain',
                ],
            ]);

            $this->logger->info('Response from API: '.$response->getContent(false));

            return json_decode($response->getContent(false));
        } catch (Throwable $e) {
            throw new APIException($e->getMessage());
        }
    }

    /**
     * @throws APIException
     */
    public function updateTradingStatus(User $user, string $contract, bool $paused)
    {
        try {
            $response = $this->httpClient->request('POST', $this->baseUrl.'/updateTradingStatus', [
                'query' => [
                    'userId' => $user->getId(),
                    'contract' => $contract,
                    'paused' => $paused ? 'true' : 'false',
                ],
                'headers' => [
                    'Authorization' => 'Bearer '.$this->secret,
                    'Content-Type' => 'text/plain',
                ],
            ]);

            $this->logger->info('Response from API: '.$response->getContent(false));

            return json_decode($response->getContent(false));
        } catch (Throwable $e) {
            throw new APIException($e->getMessage());
        }
    }
}
