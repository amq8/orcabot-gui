<?php

namespace App\Repository;

use App\Entity\AutoTrade;
use App\Entity\User;
use App\Service\ChartService;
use DateTime;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use Exception;
use Knp\Component\Pager\PaginatorInterface;

/**
 * @method AutoTrade|null find($id, $lockMode = null, $lockVersion = null)
 * @method AutoTrade|null findOneBy(array $criteria, array $orderBy = null)
 * @method AutoTrade[]    findAll()
 * @method AutoTrade[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class AutoTradeRepository extends ServiceEntityRepository
{
    private $test;
    private $paginator;
    private $chartService;

    public function __construct(
        ManagerRegistry $registry,
        PaginatorInterface $paginator,
        ChartService $chartService,
        string $env
    ) {
        parent::__construct($registry, AutoTrade::class);
        $this->paginator = $paginator;
        $this->chartService = $chartService;
        $this->test = 'dev' === $env;
    }

    public function getLatestUserTrades(User $user, int $limit)
    {
        $qb = $this->createQueryBuilder('t')
            ->select()
            ->where('t.userId = :uid');
        if (!$this->test) {
            $qb = $qb->andWhere('t.test = false');
        }

        return $qb
            ->orderBy('t.id', 'DESC')
            ->setMaxResults($limit)
            ->setParameter('uid', $user->getId())
            ->getQuery()->execute();
    }

    public function getPaginatedUserTrades(User $user, int $page)
    {
        $qb = $this->createQueryBuilder('t')
            ->select()
            ->where('t.userId = :uid')
            ->setParameter('uid', $user->getId());
        if (!$this->test) {
            $qb = $qb->andWhere('t.test = false');
        }

        return $this->paginator->paginate($qb->getQuery(), $page, 25, [
            'defaultSortFieldName' => 't.id',
            'defaultSortDirection' => 'desc',
        ]);
    }

    /**
     * @return mixed
     *
     * @throws Exception
     */
    public function getDailyUserPnL(User $user, DateTime $from, DateTime $to)
    {
        $qb = $this->createQueryBuilder('t')
            ->select("DATE_FORMAT(t.closedAt, 'YYYY-MM-DD') AS date")
            ->addSelect('SUM(t.net) AS total')
            ->andWhere('t.userId = :uid')
            ->andWhere("t.status = 'CLOSED'")
            ->andWhere("t.result != 'CANCELLED'")
            ->andWhere('t.closedAt BETWEEN :from AND :to')
            ->andWhere("t.quoteAsset = 'USDT'")
            ->addGroupBy('date')
            ->orderBy('date')
            ->setParameters(['uid' => $user->getId(), 'from' => $from, 'to' => $to]);

        if (!$this->test) {
            $qb = $qb->andWhere('t.test = false');
        }

        return $this->chartService->buildChartResult(
            $qb->getQuery()->getResult(),
            ['total'],
            $from,
            $to
        )['total']['daily'];
    }

    /**
     * @return mixed
     *
     * @throws Exception
     */
    public function getCumulativeUserPnL(User $user, DateTime $until)
    {
        $qb = $this->createQueryBuilder('t')
            ->select('SUM(t.net) AS total')
            ->andWhere('t.userId = :uid')
            ->andWhere("t.status = 'CLOSED'")
            ->andWhere("t.result != 'CANCELLED'")
            ->andWhere('t.closedAt < :until')
            ->andWhere("t.quoteAsset = 'USDT'")
            ->setParameters(['uid' => $user->getId(), 'until' => $until]);

        if (!$this->test) {
            $qb = $qb->andWhere('t.test = false');
        }

        return $qb->getQuery()->getSingleScalarResult();
    }
}
