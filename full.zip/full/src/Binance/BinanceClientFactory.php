<?php

namespace App\Binance;

use App\Entity\BinanceAccount;
use JetBrains\PhpStorm\Pure;
use Psr\Log\LoggerInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Symfony\Contracts\Service\Attribute\Required;

class BinanceClientFactory
{
    #[Required] public HttpClientInterface $httpClient;
    #[Required] public LoggerInterface $logger;

    #[Pure]
    public function create(BinanceAccount $account): BinanceClient
    {
        return new BinanceClient($this->httpClient, $this->logger, $account->getApiKey(), $account->getSecretKey());
    }
}
