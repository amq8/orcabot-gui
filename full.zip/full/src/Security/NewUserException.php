<?php

namespace App\Security;

use JetBrains\PhpStorm\Pure;
use Symfony\Component\Security\Core\Exception\AuthenticationException;

class NewUserException extends AuthenticationException
{
    /** @var array{id: number, username: string} */
    private array $credentials;

    #[Pure]
    public function __construct(array $credentials)
    {
        parent::__construct();
        $this->credentials = $credentials;
    }

    /**
     * @return array{id: number, username: string}
     */
    public function getCredentials(): array
    {
        return $this->credentials;
    }
}
