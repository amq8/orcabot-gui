#!/bin/sh
set -e

sudo -u www-data git pull
sudo -u www-data composer dump-autoload --no-dev --classmap-authoritative
sudo -u www-data ./bin/console cache:clear --no-warmup -e prod
sudo -u www-data yarn install
sudo -u www-data yarn encore production
sudo -u www-data composer install
sudo -u www-data composer dump-env prod
sudo -u www-data composer dump-autoload --no-dev --classmap-authoritative
sudo chown -R www-data:www-data .