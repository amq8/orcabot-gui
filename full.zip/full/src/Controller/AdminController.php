<?php

namespace App\Controller;

use App\Binance\BinanceClient;
use App\Coinbase\CoinbaseClient;
use App\Entity\Balance;
use App\Repository\UserRepository;
use DateTime;
use Exception;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Throwable;

class AdminController extends AbstractController
{
    /**
     * @Route("/admin", name="admin_index")
     */
    public function adminIndex(BinanceClient $withdrawBinance): Response
    {
        $withdrawBalances = [];
        try {
            $withdrawBalancesRaw = $withdrawBinance->accountInfo()['balances'];
            foreach ($withdrawBalancesRaw as $bal) {
                if ((float) $bal['free'] > 0) {
                    $withdrawBalances[] = $bal['free'].$bal['asset'];
                }
            }
        } catch (Exception $e) {
            $withdrawBalances[] = $e->getMessage();
        }

        return $this->render('admin/index.html.twig', [
            'withdrawBalances' => $withdrawBalances,
            'userBalance' => $this->getDoctrine()->getRepository(Balance::class)->getTotalBalance('USDT'),
        ]);
    }

    /**
     * @Route("/admin/users", name="admin_users")
     */
    public function adminUsers(UserRepository $userRepository, PaginatorInterface $paginator, Request $request): Response
    {
        $pagination = $paginator->paginate(
            $userRepository->createQueryBuilder('user')->getQuery(),
            $request->query->getInt('page', 1), 25,
            ['defaultSortFieldName' => 'user.id', 'defaultSortDirection' => 'desc']
        );

        return $this->render('admin/users.html.twig', ['pagination' => $pagination]);
    }

    /**
     * @Route("/admin/charts", name="admin_charts")
     *
     * @throws Throwable
     */
    public function adminCharts(Request $request, BinanceClient $withdrawBinance, CoinbaseClient $coinbase): Response
    {
        $variationPair = $request->get('variationPair', 'BTCUSDT');
        $interval = $request->get('interval', '1h');

        if (!in_array($variationPair, ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'LTCUSDT', 'XMRUSDT'], true)) {
            throw $this->createNotFoundException();
        }

        if (!in_array($interval, ['1h', '4h', '6h', '1d'], true)) {
            throw $this->createNotFoundException();
        }

        $from = (new DateTime('-1 month'))->setTime(0, 0);

        $klines = $withdrawBinance->klines(
            $variationPair,
            $interval,
            $from->getTimestamp() * 1000
        );

        $variationChart = [];

        for ($i = 1, $max = count($klines); $i < $max; ++$i) {
            $open = (float) $klines[$i][2];
            $lastOpen = (float) $klines[$i - 1][2];
            $variationChart[] = [
                'x' => $klines[$i][0],
                'y' => number_format((($open - $lastOpen) / $lastOpen) * 100, 4),
                'value' => $open,
            ];
        }

        $coinbasePremiumChart = null;

        if ('BTCUSDT' === $variationPair && in_array($interval, ['1h', '6h', '1d'], true)) {
            $coinbaseRates = array_reverse($coinbase->getHistoricRates(
                'BTC-USD',
                $from,
                new DateTime(),
                ['1h' => 3600, '6h' => 21600, '1d' => 86400][$interval]
            ));
            $coinbasePremiumChart = ['value' => [], 'percent' => []];

            // skip first to sync charts
            for ($i = 1, $max = count($klines); $i < $max; ++$i) {
                $binanceOpen = (float) $klines[$i][2];
                $coinbaseOpen = $coinbaseRates[$i]['open'];
                $coinbasePremiumChart['value'][] = [
                    'x' => $klines[$i][0],
                    'y' => number_format($binanceOpen - $coinbaseOpen, 2, '.', ''),
                ];
                $coinbasePremiumChart['percent'][] = [
                    'x' => $klines[$i][0],
                    'y' => number_format((($binanceOpen - $coinbaseOpen) / $coinbaseOpen) * 100, 2, '.', ''),
                ];
            }
        }

        return $this->render('admin/charts.html.twig', [
            'variationChart' => $variationChart,
            'coinbasePremiumChart' => $coinbasePremiumChart,
            'interval' => $interval,
            'variationPair' => $variationPair,
        ]);
    }

    /**
     * @Route("/admin/debug", name="admin_debug")
     */
    public function adminDebug(): Response
    {
        return $this->json([]);
    }
}
